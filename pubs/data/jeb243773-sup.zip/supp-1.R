# R Script for the "Effects of soft and rough surfaces on suction-based adhesion"
# Jonathan M. Huie & Adam P. Summers
# April 2022 

# Set Up ------------------------------------------------------------------
# clear previous environment
rm(list = ls(all=TRUE))

# load in necessary packages
library(dplyr)
library(ggplot2)
library(patchwork)
library(lme4)
library(emmeans)
library(performance)
library(readxl)

# Load Data ---------------------------------------------------------------

Data <- read_excel("Clingfish_JEB_TableS1.xlsx", sheet = 1, na = "NA") %>% data.frame
colnames(Data) <- c("Specimen","Type", "Material", "Standard_Length", 
                    "Mass", "Disc_Area", "Surf_Rough_Cat", "Surf_Stiff_Cat", "Adhesion_Force", "Tensile_Stress",
                    "Time", "Work", "Citation")
Data[,c(4:6,9:12)] <- apply((Data[,c(4:6,9:12)]),2,as.numeric) 

col = c("#D81B60","#1E88E5","#FFC107")

# Mixed Effects Models ----------------------------------------------------

# Clingfish LME
ClingData <- filter(Data, Material == "Fish")
Cling.lme <-lmer(Tensile_Stress ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen) , data = ClingData)
Cling.lme
emmeans(Cling.lme, ~  Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Cling.lme)


Cling.lme <-lmer(Time ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen) , data = ClingData)
Cling.lme
summary(Cling.lme)
emmeans(Cling.lme, ~  Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Cling.lme)

Cling.lme <-lmer(Work ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = ClingData)
Cling.lme
emmeans(Cling.lme, ~  Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Cling.lme)

# Commercial Cup LME
CommercialData <- filter(Data, Material == "None" )
Comm.lme <-lmer(Tensile_Stress ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = CommercialData)
Comm.lme
emmeans(Comm.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Comm.lme)

Comm.lme <-lmer(Time ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = CommercialData)
Comm.lme
emmeans(Comm.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Comm.lme)

Comm.lme <-lmer(Work ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = CommercialData)
Comm.lme
emmeans(Comm.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Comm.lme)

# Eco 10 Overmold LME
OvermoldData <- filter(Data, Material == "Eco10" )
Over.lme <-lmer(Tensile_Stress ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = OvermoldData)
Over.lme
emmeans(Over.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Over.lme)

Over.lme <-lmer(Time ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = OvermoldData)
Over.lme
emmeans(Over.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Over.lme)

Over.lme <-lmer(Work ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = OvermoldData)
Over.lme
emmeans(Over.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Over.lme)

# Eco 30 Overmold LME
OvermoldData <- filter(Data, Material == "Eco30" )
Over.lme <-lmer(Tensile_Stress ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = OvermoldData)
Over.lme
emmeans(Over.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Over.lme)

Over.lme <-lmer(Time ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = OvermoldData)
Over.lme
emmeans(Over.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Over.lme)

Over.lme <-lmer(Work ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = OvermoldData)
Over.lme
emmeans(Over.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Over.lme)

# Eco 50 Overmold LME
OvermoldData <- filter(Data, Material == "Eco50" )
Over.lme <-lmer(Tensile_Stress ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = OvermoldData)
Over.lme
emmeans(Over.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Over.lme)

Over.lme <-lmer(Time ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = OvermoldData)
Over.lme
emmeans(Over.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Over.lme)

Over.lme <-lmer(Work ~ Surf_Stiff_Cat * Surf_Rough_Cat + (1|Specimen), data = OvermoldData)
Over.lme
emmeans(Over.lme, ~ Surf_Rough_Cat | Surf_Stiff_Cat)
r2_nakagawa(Over.lme)


# Plot Stress -------------------------------------------------------------

a <- ggplot(filter(Data, Material == "Fish"), aes(x = Surf_Stiff_Cat, y = Tensile_Stress)) + 
  geom_hline(aes(yintercept=101, linetype="Theoretical"), color = "red", lwd = .9, lty = 2) +
  geom_boxplot(fill = "transparent", width = 0.8, lwd = .6, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.3, alpha = 0.75)+
  scale_color_manual(values = col, name = "Roughness", labels = c("Glass" = "Smooth", "P240" = "Less Rough", "P60" = "Rough")) +
  labs(title = "Clingfish", x = "\nSubstrate Material", y = "Max Stress (kPa)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,102)+
  theme_classic()+
  theme(plot.title = element_text(hjust = 0.5, size = 11),
        #legend.position = "none",
        legend.justification=c(0,1), 
        legend.position=c(0.0, 0.95),
        legend.background = element_blank(),
        legend.key = element_blank(),
        legend.text = element_text(size=10),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

b <- ggplot(filter(Data, Material == "None"), aes(x = Surf_Stiff_Cat, y = Tensile_Stress)) + 
  geom_hline(aes(yintercept=101, linetype="Theoretical"), color = "red", lwd = .9, lty = 2) +
  geom_boxplot(fill = "transparent", width = 0.8, lwd = .6, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.2, alpha = 0.75)+
  scale_color_manual(values = col) +
  labs(title = "Commercial Cup", x = "\nSubstrate Material", y = "Max Stress (kPa)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,102) +
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

c <- ggplot(filter(Data, Material == "Eco10"), aes(x = Surf_Stiff_Cat, y = Tensile_Stress)) + 
  geom_hline(aes(yintercept=101, linetype="Theoretical"), color = "red", lwd = .9, lty = 2) +
  geom_boxplot(fill = "transparent", width = 0.8, lwd = .6, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.2, alpha = 0.75)+
  scale_color_manual(values = col) +
  labs(title = "Eco 10 Overmold", x = "\nSubstrate Material", y = "Max Stress (kPa)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,102) +
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

d <- ggplot(filter(Data, Material == "Eco30"), aes(x = Surf_Stiff_Cat, y = Tensile_Stress)) + 
  geom_hline(aes(yintercept=101, linetype="Theoretical"), color = "red", lwd = .9, lty = 2) +
  geom_boxplot(fill = "transparent", width = 0.8,lwd = .6,  outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.2, alpha = 0.75)+
  scale_color_manual(values = col) +
  labs(title = "Eco 30 Overmold", x = "\nSubstrate Material", y = "Max Stress (kPa)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,102) +
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

e <- ggplot(filter(Data, Material == "Eco50"), aes(x = Surf_Stiff_Cat, y = Tensile_Stress)) + 
  geom_hline(aes(yintercept=101, linetype="Theoretical"), color = "red", lwd = .9, lty = 2) +
  geom_boxplot(fill = "transparent", width = 0.8,  outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.2, alpha = 0.75)+
  scale_color_manual(values = col) +
  labs(title = "Eco 50 Overmold", x = "\nSubstrate Material", y = "Max Stress (kPa)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,102) +
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

p3 <-c + d + e
(a | b ) / p3 + plot_annotation(tag_levels = "A") &
  theme(plot.tag.position = c(0, 1),plot.tag = element_text(size = 15))


# Plot Time ---------------------------------------------------------------

a <- ggplot(filter(Data, Material == "Fish" & Surf_Stiff_Cat != "Hard"), aes(x = Surf_Stiff_Cat, y = Time)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8, lwd = .6, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.3, alpha = 0.75)+
  scale_color_manual(values = col, name = "Roughness", labels = c("Glass" = "Smooth", "P240" = "Less Rough", "P60" = "Rough"), guide = F) +
  labs(title = "Clingfish", x = "\nSubstrate Material", y = "Time (s)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50")) +
  ylim(0,2.5)+
  theme_classic()+
  theme(plot.title = element_text(hjust = 0.5, size = 11),
        legend.justification=c(0,1), 
        legend.position=c(0.0, 0.95),
        legend.background = element_blank(),
        legend.key = element_blank(),
        legend.text = element_text(size=10),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

b <- ggplot(filter(Data, Material == "None" ), aes(x = Surf_Stiff_Cat, y = Time)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8, lwd = .6, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.3, alpha = 0.75)+
  scale_color_manual(values = col, name = "Roughness", labels = c("Glass" = "Smooth", "P240" = "Less Rough", "P60" = "Rough")) +
  labs(title = "Commercial Cup", x = "\nSubstrate Material", y = "Time (s)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,2.5)+
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

c <- ggplot(filter(Data, Material == "Eco10"), aes(x = Surf_Stiff_Cat, y = Time)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8, lwd = .6, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.3, alpha = 0.75)+
  scale_color_manual(values = col, name = "Roughness", labels = c("Glass" = "Smooth", "P240" = "Less Rough", "P60" = "Rough")) +
  labs(title = "Eco 10 Overmold", x = "\nSubstrate Material", y = "Time (s)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,2.5)+
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

d <- ggplot(filter(Data, Material == "Eco30" ), aes(x = Surf_Stiff_Cat, y = Time)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8,lwd = .6,  outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.3, alpha = 0.75)+
  scale_color_manual(values = col, name = "Roughness", labels = c("Glass" = "Smooth", "P240" = "Less Rough", "P60" = "Rough")) +
  labs(title = "Eco 30 Overmold", x = "\nSubstrate Material", y = "Time (s)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,2.5)+
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

e <- ggplot(filter(Data, Material == "Eco50" ), aes(x = Surf_Stiff_Cat, y = Time)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8,lwd = .6,  outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.3, alpha = 0.75)+
  scale_color_manual(values = col, name = "Roughness", labels = c("Glass" = "Smooth", "P240" = "Less Rough", "P60" = "Rough")) +
  labs(title = "Eco 50 Overmold", x = "\nSubstrate Material", y = "Time (s)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,2.5)+
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

p3 <-c + d + e
(a | b ) / p3 + plot_annotation(tag_levels = "A") &
  theme(plot.tag.position = c(0, 1),plot.tag = element_text(size = 15))




# Plot Work ---------------------------------------------------------------

a <- ggplot(filter(Data, Material == "Fish" & Surf_Stiff_Cat != "Hard" ), aes(x = Surf_Stiff_Cat, y = Work)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.3, alpha = 0.75)+
  scale_color_manual(values = col, name = "Roughness", labels = c("Glass" = "Smooth", "P240" = "Less Rough", "P60" = "Rough"), guide = F) +
  labs(title = "Clingfish", x = "\nSubstrate Material", y = "Work (J)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50")) +
  ylim(0,0.8) +
  #ylim(-1.35,1.3) +
  theme_classic()+
  theme(plot.title = element_text(hjust = 0.5, size = 11),
        legend.justification=c(0,1), 
        legend.position=c(0.0, 1),
        legend.background = element_blank(),
        legend.key = element_blank(),
        legend.text = element_text(size=8),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

b <- ggplot(filter(Data, Material == "None"), aes(x = Surf_Stiff_Cat, y = Work)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.2, alpha = 0.75)+
  scale_color_manual(values = col) +
  labs(title = "Commercial Cup", x = "\nSubstrate Material", y = "Work (J)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,0.8) +
  #ylim(-1.35,1.3) +
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

c <- ggplot(filter(Data, Material == "Eco10" ), aes(x = Surf_Stiff_Cat, y = Work)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.2, alpha = 0.75)+
  scale_color_manual(values = col) +
  labs(title = "Eco 10 Overmold", x = "\nSubstrate Material", y = "Work (J)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,0.8) +
  #ylim(-1.35,1.3) +
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

d <- ggplot(filter(Data, Material == "Eco30"), aes(x = Surf_Stiff_Cat, y = Work)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.2, alpha = 0.75)+
  scale_color_manual(values = col) +
  labs(title = "Eco 30 Overmold", x = "\nSubstrate Material", y = "Work (J)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,0.8) +
  #ylim(-1.35,1.3) +
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

e <- ggplot(filter(Data, Material == "Eco50" ), aes(x = Surf_Stiff_Cat, y = Work)) + 
  #geom_violin(fill = "darkgrey") + 
  geom_boxplot(fill = "transparent", width = 0.8, outlier.colour = "transparent") + 
  geom_jitter(aes(col = Surf_Rough_Cat), width = 0.2, alpha = 0.75)+
  scale_color_manual(values = col) +
  labs(title = "Eco 50 Overmold", x = "\nSubstrate Material", y = "Work (J)") +
  scale_x_discrete(labels=c("Eco10" = "Eco10", "Eco30" = "Eco30","Eco50" = "Eco50", "Hard" = "Epoxy")) +
  ylim(0,0.8) +
  theme_classic() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 11),
        axis.text=element_text(size=8),
        axis.title=element_text(size=10))

p3 <-c + d + e
(a | b ) / p3  + plot_annotation(tag_levels = "A") &
  theme(plot.tag.position = c(0, 1),plot.tag = element_text(size = 15))



# Effective Elastic Modulus -----------------------------------------------
ManMade <- Data
ManMade <- filter(Data, !Material == "Fish" )
ManMade$Type[grep("Eco",ManMade$Material)] <- "Overmold"

# set Elastic modulus 
ManMade$CupE <- NA 
ManMade[which(ManMade$Material == "Eco10"),"CupE"] <- 55 # overmold 10
ManMade[which(ManMade$Material == "Eco30"),"CupE"] <- 69 # overmold 30
ManMade[which(ManMade$Material == "Eco50"),"CupE"] <- 83 # overmold 50
ManMade[which(ManMade$Material == "None"),"CupE"] <-  8000 # commercial cup

ManMade$SurfaceE <- NA # epoxy surface 
ManMade[which(ManMade$Surf_Stiff_Cat == "Eco10"),"SurfaceE"] <- 55 # overmold 10
ManMade[which(ManMade$Surf_Stiff_Cat == "Eco30"),"SurfaceE"] <- 69 # overmold 30
ManMade[which(ManMade$Surf_Stiff_Cat == "Eco50"),"SurfaceE"] <- 83 # overmold 50
ManMade[which(ManMade$Surf_Stiff_Cat == "Hard"),"SurfaceE"] <-  3520000 # commercial cup

# set Poisson's ratio 
ManMade$CupP <- 0.5 #overmold cups
ManMade[which(ManMade$Material == "None"),"SurfaceP"] <- 0.4 # commercial cup
ManMade$SurfaceP <- 0.5 # epoxy surface 
ManMade[which(ManMade$Surf_Stiff_Cat == "Hard"),"SurfaceP"] <- 0.3 # silicone surface 

# calculate effective elastic modulus
ManMade$EffectiveE <- 1/((1 - ManMade$CupP^2)/(ManMade$CupE)+
                         (1 -ManMade$SurfaceP^2)/(ManMade$SurfaceE))


# fit one line through all data
lm1 <- lm(Tensile_Stress~(1/EffectiveE), data = ManMade)
lm1
summary(lm1)

# fit one line through commercial and one through overmold
lm2 <- lm(Tensile_Stress~(1/EffectiveE)*Type, data = ManMade)
lm2
summary(lm2)

# fit one line through commercial and one for the three overmold cups
lm3 <- lm(Tensile_Stress~(1/EffectiveE)*Material, data = ManMade)
lm3
summary(lm3)

c(AIC(lm1), AIC(lm2), AIC(lm3)) # lm3 is the best fit


# Plot Figure 5 -----------------------------------------------------------

ManMade$Material[ManMade$Material =="None"] <-"Commercial"
a <- ggplot(ManMade,aes(x = ifelse(EffectiveE>10000,250,EffectiveE), y = (Tensile_Stress), col = Material, linetype = Material)) +
  geom_hline(aes(yintercept=101, linetype="Theoretical"), color = "red", lwd = .9, lty = 2) +
  scale_color_manual(values = c("#004D40", col[c(1,2,3)]), labels=c("Commercial" = "Commercial","Eco10" = "Ecoflex 10 Overmold", "Eco30" = "Ecoflex 30 Overmold", "Eco50" = "Ecoflex 50 Overmold")) +
  scale_linetype_manual(values=c("longdash", "dotdash", "dashed", "solid"), guide = "none") +
  labs(x = "Effective Elastic Modulus (kPa)", y = "Max Tensile Stress (kPa)", col = "Cup Type") +
  scale_x_continuous(breaks = c(50,100,150,200,250), labels = c("50","100","150","200","10000+"))+
  geom_point(aes(col = Material), size = 2) +
  ylim(18,101)+
  theme_classic() +
  theme(plot.title = element_text(hjust = 0.5),
        legend.justification=c(0,1), 
        legend.position=c(.01, 0.93),
        legend.background = element_blank(),
        legend.key = element_blank(),
        legend.key.size = unit(.35, "cm"),
        legend.text = element_text(size = 9),
        legend.title = element_text(size =10),
        axis.text=element_text(size=10),
        axis.title=element_text(size=12)) 

b <- ggplot(ManMade,aes(x = (1/EffectiveE), y = (Tensile_Stress), col = Material, linetype = Material)) +
  geom_hline(aes(yintercept=101, linetype="Theoretical"), color = "red", lwd = .9, lty = 2) +
  scale_color_manual(values = c("#004D40", col[c(1,2,3)]), labels=c("Commercial" = "Commercial","Eco10" = "Ecoflex 10 Overmold", "Eco30" = "Ecoflex 30 Overmold", "Eco50" = "Ecoflex 50 Overmold")) +
  scale_linetype_manual(values=c("longdash", "dotdash", "dashed", "solid"), guide = "none") +
  labs(x = expression(paste("Inverse of Effective Elastic Modulus " (kPa^-1))), y = "Max Tensile Stress (kPa)", col = "Cup Type") +
  geom_smooth(method=lm, se=T, fill = "grey80") +
  geom_point(aes(col = Material), size = 2) +
  ylim(18,101)+
  theme_classic() +
  theme(plot.title = element_text(hjust = 0.5),
        legend.justification=c(0,1), 
        legend.position = "none")

(a / b )  + plot_annotation(tag_levels = "A") &
  theme(plot.tag.position = c(0, 1),plot.tag = element_text(size = 15))
