# Supporting R script for:
## Huie JM, Arnette SD, Evans AJ, Cohen KE, Buser TJ, Crawford CH, Kane EA, Kolmann MA. 
## Behavioral novelties and morphological exaptation underlie trophic novelty in an anemone-feeding fish. 
# 
# 
# Code written by Jonathan M. Huie


# clear previous environment
rm(list = ls(all=TRUE))

# load in necessary packages
library(phytools)
library(plyr)
library(ggplot2)

# Auxillary Functions -----------------------------------------------------

# phylomorphospace function for plotting branches with ggplot 
geom_tree <- function(dat = NULL, axis1 = 1, axis2 = 2, tree = NULL, size = .5){
  X <- dat[,c(axis1,axis2)]
  A <- apply(X, 2, fastAnc, tree = tree)
  aa <- setNames(c(X[tree$tip.label, 1], A[, 1]), c(1:length(tree$tip.label), rownames(A)))
  # combines the tips and node PC scores for PC 2
  bb <- setNames(c(X[tree$tip.label, 2], A[, 2]), c(1:length(tree$tip.label), rownames(A)))
  # gets the PC 1 score for all of the values in tree$edge (tip and nodes)
  XX <- matrix(aa[as.character(tree$edge)], nrow(tree$edge), 2)
  # gets the PC 2 score for all of the values in tree$edge (tip and nodes)
  YY <- matrix(bb[as.character(tree$edge)], nrow(tree$edge), 2)
  lines <- as.data.frame(cbind(XX,YY))
  
  test <- geom_segment(aes(x = lines[,1], y = lines[,3], xend = lines[,2], yend = lines[,4]), 
                       col = "grey50", data = lines, linewidth = size) 
  
  return(test)
}

# phylomorphospace function for plotting internal nodes with ggplot
geom_nodes <- function(dat = NULL, axis1 = 1, axis2 = 2, tree = NULL, size= 2.2){
  X <- dat[,c(axis1,axis2)]
  A <- apply(X, 2, fastAnc, tree = tree)
  aa <- setNames(c(X[tree$tip.label, 1], A[, 1]), c(1:length(tree$tip.label), rownames(A)))
  # combines the tips and node PC scores for PC 2
  bb <- setNames(c(X[tree$tip.label, 2], A[, 2]), c(1:length(tree$tip.label), rownames(A)))
  # gets the PC 1 score for all of the values in tree$edge (tip and nodes)
  XX <- matrix(aa[as.character(tree$edge)], nrow(tree$edge), 2)
  # gets the PC 2 score for all of the values in tree$edge (tip and nodes)
  YY <- matrix(bb[as.character(tree$edge)], nrow(tree$edge), 2)
  lines <- as.data.frame(cbind(XX,YY))
  
  test <- geom_point(aes(x = lines[,1], y = lines[,3]),
                     col = "grey50", data = lines, size = size) 
  
  return(test)
}

# Load Data ---------------------------------------------------------------

# load in supporting table 1
tables1 <- read.csv("TableS1.csv")
tables1$Species <- gsub(" ","_",tables1$Species)

# size correct non-ratios
resid.data <- tables1[1:62,-c(3,4,14:16)] # subset functional morphology data
resid.data[,3:11] <- log(resid.data[,3:11])
for (i in c(8:11)) {
  resid.data[,i] <- lm(resid.data[,i]~resid.data[,3])$residuals
}

col <- setNames(c("#db8424","#39c661","#2955d6","#db8424","#db8424"),
                c("Clinocottus_embryum", "Clinocottus_globiceps","Clinocottus_recalvus", 
                  "Oligocottus_maculosus", "Orthonopias_triacis"))

# Tree --------------------------------------------------------------------

# load in Buser et al. 2017 sculpin phylogeny
tree <- read.nexus("Buser2017_sculpintree.tree")
tree <- drop.tip(tree,setdiff(tree$tip.label, unique(resid.data$Species)))
plot(tree)

# ANCESTRAL STATE RECON (normal diet categories)
diet <- setNames(c("Arthropods", "Anemone","Algae","Arthropods","Arthropods"),
                 c("Clinocottus_embryum", "Clinocottus_globiceps","Clinocottus_recalvus", 
                   "Oligocottus_maculosus", "Orthonopias_triacis"))
diet.col <- setNames(c("#39c661","#2955d6","#db8424"),c( "Anemone","Algae", "Arthropods"))

#find the best fiting model
er <- fitMk(tree, diet, model = "ER", nsim = 1)
sym <- fitMk(tree, diet, model = "SYM", nsim = 1)
ard <- fitMk(tree, diet, model = "ARD", nsim = 1)

aic<-as.matrix(sapply(list(ER=er,SYM=sym,ARD=ard),AIC))
aic # ER is best

sim <- make.simmap(tree, diet, model = "ER", nsim = 1000)
pd <- describe.simmap(sim)
plot(tree, lwd =2, label.offset = 0.001)
nodelabels(pie=pd$ace, piecol = diet.col[colnames(pd$ace)], cex = 1)
tiplabels(pch =21, bg = diet.col[diet], cex = 2)
legend("topleft", legend = c("Anemones", "Algae", "Arthropods"), 
       pch = 21, pt.bg = diet.col, cex = 0.75, pt.cex = 1.5, bty = "n")

# ANCESTRAL STATE RECON (synthetic categories from Buser et al. 2019)
diet2 <- setNames(c("TentnAppend", "TentnAppend","StatBenth","BenthArth","BenthArth"),
                 c("Clinocottus_embryum", "Clinocottus_globiceps","Clinocottus_recalvus", 
                   "Oligocottus_maculosus", "Orthonopias_triacis"))
diet.col2 <- setNames(c("#39c661","#2955d6","#db8424"),c( "TentnAppend","StatBenth", "BenthArth"))

#find the best fiting model
er <- fitMk(tree, diet2, model = "ER", nsim = 1)
sym <- fitMk(tree, diet2, model = "SYM", nsim = 1)
ard <- fitMk(tree, diet2, model = "ARD", nsim = 1)

aic<-as.matrix(sapply(list(ER=er,SYM=sym,ARD=ard),AIC))
aic # ER is best

sim <- make.simmap(tree, diet2, model = "ER", nsim = 1000)
pd <- describe.simmap(sim)
plot(tree, lwd =2, label.offset = 0.001)
nodelabels(pie=pd$ace, piecol = diet.col2[colnames(pd$ace)], cex = 1)
tiplabels(pch =21, bg = diet.col2[diet2], cex = 2)
legend("topleft", legend = c("Tentacles and Appendages", "Stationary Benthic Items", "Benthic Arthropods"), 
       pch = 21, pt.bg = diet.col2, cex = 0.75, pt.cex = 1.5, bty = "n")

# PCA ---------------------------------------------------------------------

# perform PCA
pca <- princomp(resid.data[,4:11], cor = T)
biplot(pca)

# plot phylomorphospace with intraspecific variation and species means
# use custom functions to add the phylogeny
scores <- cbind(Species = resid.data$Species, as.data.frame(pca$scores))
mean <- cbind(tapply(pca$scores[,1],resid.data$Species,mean),tapply(pca$scores[,2],resid.data$Species,mean))
hm <- col[as.factor(resid.data$Species)]; names(hm) <- NULL
hulls <- ddply(scores, .(Species), function(scores) scores[chull(scores[,2], scores[,3]), ])
ggplot() + 
  geom_polygon(data=hulls, aes(x = hulls[,2], y = hulls[,3], group=Species, fill = Species, colour = Species), 
               alpha = 0.4, show.legend = FALSE) +
  scale_colour_manual(values = col) +
  scale_fill_manual(values = col,
                    guide = guide_legend(override.aes = aes(shape = 21, color = "black"))) +
  geom_tree(dat = mean, axis1 = 1, axis2 = 2, tree = tree)+
  geom_nodes(dat = mean, axis1 = 1, axis2 = 2, tree = tree)+
  geom_point(as.data.frame(scores), mapping = aes(x = data.frame(scores)[,2], y = data.frame(scores)[,3]),
             shape = 19, colour = hm, size = 2.5, show.legend = F)+
  geom_point(as.data.frame(mean), mapping = aes(x = data.frame(mean)[,1], y = data.frame(mean)[,2]),
             shape = 21, stroke = 0.8, fill = col,colour = "black", size = 5, show.legend = F)+
  xlab(paste0("PC",1," (",round(pca$sdev[1]^2/sum(pca$sdev^2)*100,1),"%)")) +
  ylab(paste0("PC",2," (",round(pca$sdev[2]^2/sum(pca$sdev^2)*100,1),"%)")) + 
  theme_classic()

# DiceCT ------------------------------------------------------------------

# subset jaw muscle volume data
dice.data <- tables1[63:67,c(1,5,14:16)]
dice.data$Species <- factor(dice.data$Species, levels = c("Oligocottus_maculosus", 
                                                          "Orthonopias_triacis", 
                                                          "Clinocottus_embryum",
                                                          "Clinocottus_recalvus",
                                                          "Clinocottus_globiceps"))

ggplot() +
  geom_point(dice.data, mapping = aes(x=Species, y = log(A1.Volume/SL^3), col = Species), shape = 22, size = 6, stroke = 1.25, show.legend = F)+
  geom_point(dice.data, mapping = aes(x=Species, y = log(A2.Volume/SL^3), col = Species), shape = 21, size = 5, stroke = 1.25,show.legend = F)+
  geom_point(dice.data, mapping = aes(x=Species, y = log(A3.Volume/SL^3), col = Species), shape = 24, size = 5, stroke = 1.25,show.legend = F)+
  scale_x_discrete(labels=c("O. maculosus", "O. triacis", "C. embryum", "C. recalvus", "C. globiceps"),
                   guide = guide_axis(n.dodge = 2))+
  ylab(label = expression(paste("Volume / Standard ", Length^{3})))+
  scale_colour_manual(values = col) +
  theme_classic()

